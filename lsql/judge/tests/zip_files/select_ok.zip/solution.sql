SELECT Sede, Nombre
FROM Club;
