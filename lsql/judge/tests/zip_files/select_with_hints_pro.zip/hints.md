3
descripcion pista 1
@@@new hint@@@
5
Ten en **cuenta** que:
 * debes seleccionar las tablas
 * debes elegir cuidadosamente las columnas
@@@new hint@@@
10
descripcion pista 3
