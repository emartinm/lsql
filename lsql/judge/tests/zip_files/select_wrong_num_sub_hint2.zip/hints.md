3
descripcion pista 1
@@@new hint@@@
cinco
descripcion pista 2
@@@new hint@@@
10
descripcion pista 3