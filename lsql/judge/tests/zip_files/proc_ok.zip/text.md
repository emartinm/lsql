Crea una función `golesLocal` que recibe una cadena de texto `VARCHAR2` representando el resultado de un partido con el formato `GolesLocal−GolesVisitante` y devuelve el número de goles del equipo local como un valor de tipo `NUMBER`. Por ejemplo, `golesLocal('3-0')` debería devolver el número `3`.

