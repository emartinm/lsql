CREATE OR REPLACE FUNCTION golesLocal(resultado VARCHAR2) RETURN NUMBER IS
  posGuion NUMBER;
  golesStr VARCHAR2(3);
BEGIN
  posGuion := INSTR(resultado, '-');
  golesStr := SUBSTR(resultado, 0, posGuion - 1);
  RETURN TO_NUMBER(golesStr);
END;
