SELECT Sede, Nombre
FROM Ejemplo;
