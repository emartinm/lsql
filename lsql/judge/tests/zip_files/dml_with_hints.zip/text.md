Considera dos tablas que almacenan datos sobre personas y árbitros de fútbol, definidas de la siguiente manera:

    CREATE TABLE Persona(
        NIF CHAR(9) PRIMARY KEY,
        Nombre VARCHAR2(20) NOT NULL
    );

    CREATE TABLE Arbitro(
        NIF CHAR(9) PRIMARY KEY REFERENCES Persona(NIF) ON DELETE CASCADE,
        Colegio VARCHAR2(20) NOT NULL,
        Fecha_colegiatura DATE NOT NULL
    );

Como todo árbitro es una persona, existe una **clave externa** en la columna `NIF` de `Arbitro` apuntando a la columna `NIF` de la tabla `Persona`. 

Escribe un **máximo de 2 sentencias SQL** para insertar un nuevo árbitro a la base de datos con lo siguientes detalles:

* **NIF**: `'00000010X'`
* **Nombre**: `'Pierluigi Collina'`
* **Colegio**: `'Italiano'`
* **Fecha_colegiatura**: 23 de marzo de 1995

Ten en cuenta que el campo **Fecha_colegiatura** tiene tipo `DATE`, así que deberás utilizar un valor de dicho tipo. Para construirlo puedes usar la función `TO_DATE` ([info](https://docs.oracle.com/cd/E11882_01/server.112/e41084/functions203.htm#SQLRF06132 "Database SQL Language Reference - TO_DATE"), [info](https://blog.mdcloud.es/funcion-oracle-to-date-ejemplos-formatos-y-usos/ "Función Oracle TO_DATE: ejemplos, formatos y usos - ADN Cloud")).