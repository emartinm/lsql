CREATE OR REPLACE TRIGGER DispCantidadFinanciacion
BEFORE INSERT OR UPDATE
ON Financia FOR EACH ROW
DECLARE
  numJug NUMBER;
BEGIN
  SELECT COUNT(*) INTO numJug
  FROM Jugador
  WHERE CIF = :NEW.CIF_C;

  IF numJug >= 2 THEN
    DBMS_OUTPUT.PUT_LINE('Aumentando Financiación de ' || :NEW.Cantidad || ' a ' || :NEW.Cantidad * 1.25);
    :NEW.Cantidad := :NEW.Cantidad * 1.25;
  END IF;
END;

