Considera una tabla que almacena algunos datos sobre clubes de fútbol definida de la siguiente manera:

    CREATE TABLE Club(
        CIF CHAR(9) PRIMARY KEY,
        Nombre VARCHAR2(40) NOT NULL UNIQUE,
        Sede VARCHAR2(30) NOT NULL,
        Num_Socios NUMBER(10,0) NOT NULL,
    );


Escribe una consulta SQL que devuelve la sede y el nombre de todos los clubes. El esquema del resultado debe ser el siguiente (**ten cuidado con el orden**):

    (Sede, Nombre)