INSERT INTO Club VALUES ('C.C. Garbí', 'Pista de Atletismo de Gandia', 2500);
INSERT INTO Club VALUES ('C.A. Safor', 'Pista de Atletismo del Grao', 2000);
INSERT INTO Club VALUES ('València Terra i Mar', 'Pista del Túria', 5000);