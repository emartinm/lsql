Queremos saber que clubes de atletismo tienen más de **1000 atletas**, los datos están almacenados de la siguiente forma:

    CREATE TABLE Club(
    Nombre VARCHAR2(40) PRIMARY KEY,
    Pista VARCHAR2(30) NOT NULL,
    Atletas NUMBER(10,0) NOT NULL,
    CONSTRAINT NumAtletas CHECK (Atletas >= 0)
	);


La solución dada por el becario es la detallada en la línea de código dew abajo. Creemos que está solución no es correcta aunque el resultado sea bueno. ¿Qué dato/s deberíamos introducir para que esta sentencia no sea correcta para este caso?: