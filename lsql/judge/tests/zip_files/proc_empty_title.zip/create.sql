CREATE TABLE Club(
    CIF CHAR(9) PRIMARY KEY, -- No puede ser NULL
    Nombre VARCHAR2(40) NOT NULL UNIQUE,
    Sede VARCHAR2(30) NOT NULL,
    Num_Socios NUMBER(10,0) NOT NULL,
    CONSTRAINT NumSociosPositivos CHECK (Num_Socios >= 0)
);

CREATE TABLE Persona(
    NIF CHAR(9) PRIMARY KEY,
    Nombre VARCHAR2(20) NOT NULL
);

CREATE TABLE Arbitro(
    NIF CHAR(9) PRIMARY KEY REFERENCES Persona(NIF) ON DELETE CASCADE,
    Colegio VARCHAR2(20) NOT NULL,
    Fecha_colegiatura DATE NOT NULL
);

CREATE TABLE Enfrenta(
    CIF_local CHAR(9) NOT NULL REFERENCES Club(CIF),
    CIF_visitante CHAR(9) NOT NULL REFERENCES Club(CIF),
    -- Por comodidad futura, supongo que 'Resultado' esta formado por dos valores:
    -- GolesLocal y GolesVisitante
    GolesLocal NUMBER(2,0) NOT NULL CHECK (GolesLocal >= 0),
    GolesVisitante NUMBER(2,0) NOT NULL CHECK (GolesVisitante >= 0),
    Fecha DATE NOT NULL,
    NIF CHAR(9) NOT NULL REFERENCES Arbitro(NIF),
    
    CONSTRAINT PKEnfrenta PRIMARY KEY (CIF_local, CIF_visitante),
    CONSTRAINT DosClubes CHECK (CIF_local <> CIF_visitante)
    -- Para evitar errores al introducir un partido
);

CREATE TABLE Asiste(
    CIF_local CHAR(9) NOT NULL,
    CIF_visitante CHAR(9) NOT NULL,
    NIF CHAR(9) NOT NULL REFERENCES Persona(NIF),
    
    CONSTRAINT FGEnfrentamiento FOREIGN KEY (CIF_local,CIF_visitante) REFERENCES Enfrenta(CIF_local, CIF_visitante)
);

