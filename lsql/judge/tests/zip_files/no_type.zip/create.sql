CREATE TABLE Club(
    CIF CHAR(9) PRIMARY KEY, -- No puede ser NULL
    Nombre VARCHAR2(40) NOT NULL UNIQUE,
    Sede VARCHAR2(30) NOT NULL,
    Num_Socios NUMBER(10,0) NOT NULL,
    CONSTRAINT NumSociosPositivos CHECK (Num_Socios >= 0)
);
