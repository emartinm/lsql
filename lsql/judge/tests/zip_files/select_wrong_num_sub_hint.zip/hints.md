-12
Es **importante** consultar las tablas `Club` e `Inversiones`