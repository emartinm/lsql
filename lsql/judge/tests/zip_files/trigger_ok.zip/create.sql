-- Definición de las tablas
CREATE TABLE Club(
    CIF CHAR(9) PRIMARY KEY, -- No puede ser NULL
    Nombre VARCHAR2(40) NOT NULL UNIQUE,
    Sede VARCHAR2(30) NOT NULL,
    Num_Socios NUMBER(10,0) NOT NULL,
    CONSTRAINT NumSociosPositivos CHECK (Num_Socios >= 0)
);

CREATE TABLE Patrocinador(
    CIF CHAR(9) PRIMARY KEY,
    NomPat VARCHAR2(20) NOT NULL, 
    Rama VARCHAR2(20) NOT NULL,
    Eslogan VARCHAR2(30) NOT NULL,
    
    -- Puede haber patrocinadores con el mismo nombre de distintas ramas
    CONSTRAINT NombreYRamaUnicos UNIQUE(NomPat,Rama)
);

CREATE TABLE Jugador(
    NIF CHAR(9) PRIMARY KEY,
    Altura NUMBER(3,2) NOT NULL CHECK (Altura > 0),
    CIF CHAR(9) NOT NULL REFERENCES Club(CIF)
);

CREATE TABLE Financia(
    CIF_P CHAR(9) NOT NULL REFERENCES Patrocinador(CIF),
    CIF_C CHAR(9) NOT NULL REFERENCES Club(CIF),
    Cantidad NUMBER(10,2) NOT NULL CHECK (Cantidad > 0),
    
    CONSTRAINT PKFinancia PRIMARY KEY (CIF_P, CIF_C)
);


