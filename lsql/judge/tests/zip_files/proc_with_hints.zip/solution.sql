CREATE OR REPLACE PROCEDURE actualiza_socios(club_cif CHAR) IS
  CURSOR cr_partidos IS SELECT CL.Nombre AS ClubL, CV.Nombre AS ClubV, COUNT(*) AS NAsistentes
                        FROM Enfrenta JOIN Asiste USING(CIF_local, CIF_visitante)
                             JOIN Club CL ON CL.CIF = CIF_Local
                             JOIN Club CV ON CV.CIF = CIF_visitante
                        WHERE CIF_local = club_cif OR CIF_visitante = club_cif
                        GROUP BY CIF_local, CIF_visitante, CL.Nombre, CV.Nombre;
  incrPartido NUMBER;
  incrTotal NUMBER := 0;
  nPartido NUMBER := 1;
  nombreClub VARCHAR2(200);
BEGIN
  SELECT Nombre 
  INTO nombreClub
  FROM Club
  WHERE CIF = club_cif;
    
  FOR partido IN cr_partidos LOOP
    IF partido.NAsistentes > 3 THEN
      incrPartido := 100;
    ELSIF partido.NAsistentes > 1 THEN
      incrPartido := 10;
    ELSE 
      incrPartido := 0;
    END IF;
    incrTotal := incrTotal + incrPartido;
    nPartido := nPartido + 1;
  END LOOP;
  UPDATE Club
  SET Num_Socios = Num_Socios + incrTotal
  WHERE CIF = club_cif;
END;
