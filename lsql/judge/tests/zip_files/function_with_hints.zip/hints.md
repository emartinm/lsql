3
Es **importante** consultar las tablas `Club` e `Inversiones`
@@@new hint@@@
5
El resultado debe proyectar las siguientes filas:
 * Nombre renombrado a "Name"
 * Sede renombrado a "Address"
@@@new hint@@@
10
La consulta debe tener un aspecto como el siguiente:
    SELECT Club.Nombre AS Name, Club.Sede AS Address
    FROM Club JOIN Inversiones ON Club.ID = Inversiones.Club
    WHERE Club.Sede = ...... AND ......