SELECT Sede, Nombre 
FROM Club 
WHERE CIF = '11111111X' and Nombre ='Madrid';
