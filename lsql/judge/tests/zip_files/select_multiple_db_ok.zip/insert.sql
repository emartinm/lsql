INSERT INTO Club VALUES ('11111111X', 'Madrid', 'A', 70000);

-- @new data base@

INSERT INTO Club VALUES ('11111111X', 'Madrid', 'A', 70000);
INSERT INTO Club VALUES ('11111112X', 'Futbol Club Barcelona', 'A', 80000);
INSERT INTO Club VALUES ('11111113X', 'Paris Saint-Germain Football Club', 'C', 1000);
                    
-- @new data base@

INSERT INTO Club VALUES ('11111111X', 'Madrid', 'A', 70000);
INSERT INTO Club VALUES ('11111112X', 'Madrid', 'B', 80000);
INSERT INTO Club VALUES ('11111114X', 'Futbol Club Barcelona', 'B', 80000);
INSERT INTO Club VALUES ('11111115X', 'Paris Saint-Germain Football Club', 'C', 1000);