3
Es **importante** consultar las tablas `Club` e `Inversiones`
@@@new hint@@@
5
