CREATE TABLE nobel(
  yr INT, 
  subject VARCHAR(12), 
  winner VARCHAR(50),
  PRIMARY KEY(yr, subject, winner));
