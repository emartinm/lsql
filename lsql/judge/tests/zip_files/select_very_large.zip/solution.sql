SELECT yr
FROM nobel;
